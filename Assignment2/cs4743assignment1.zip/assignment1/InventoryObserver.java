package assignment1;

public interface InventoryObserver {
	abstract public void updateObserver(Inventory inv);
}
