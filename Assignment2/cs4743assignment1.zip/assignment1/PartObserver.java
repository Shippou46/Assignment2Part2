package assignment1;

public interface PartObserver {
	abstract public void updateObserver(Part part);
	abstract public void modelDeleted();
}
